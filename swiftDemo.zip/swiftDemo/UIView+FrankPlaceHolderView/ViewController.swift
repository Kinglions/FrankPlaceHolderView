//
//  ViewController.swift
//  UIView+FrankPlaceHolderView
//
//  Created by Frank on 2017/6/19.
//  Copyright © 2017年 Frank. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var btn: UIButton!
    
    @IBOutlet weak var smallView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
    }

   
    @IBAction func btnClick(_ sender: Any) {
        
        self.btn.isSelected = !self.btn.isSelected
        
        if self.btn.isSelected {
            
            self.smallView.showPlaceHolderViewWithReloadButtonPosition(position: .ReloadButtonPosition_ImgButtom, showDescribe: "1234567", btnTitle: "0000000", btnClickBlock: {
                
                print("这是一个回调打印")
                
            })
            
        }else{
            
            self.smallView.hiddenPlaceHolderView()
        }
    }
}

