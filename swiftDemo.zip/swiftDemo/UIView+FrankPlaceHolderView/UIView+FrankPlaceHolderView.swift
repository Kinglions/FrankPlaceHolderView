//
//  UIView+FrankPlaceHolderView.swift
//  UIView+FrankPlaceHolderView
//
//  Created by Frank on 2017/6/19.
//  Copyright © 2017年 Frank. All rights reserved.
//

import Foundation
import UIKit


extension UIView {
    
    /// 刷新按钮位置样式
    ///
    /// - ReloadButtonPosition_None: 不显示重载按钮
    /// - ReloadButtonPosition_ImgTop: 重载按钮在图片上方
    /// - ReloadButtonPosition_ImgButtom: 重载按钮在图片下方
    /// - ReloadButtonPosition_ViewBottom: 重载按钮在视图底部
    enum ReloadButtonPosition : Int {
        
        case ReloadButtonPosition_None 
        case ReloadButtonPosition_ImgTop
        case ReloadButtonPosition_ImgButtom
        case ReloadButtonPosition_ViewBottom
        
    }
    
    
    /// 占位页对象
    var holderView:FrankPlaceHolderView? {
        
        /// setter 方法
        set {
            objc_setAssociatedObject(self, "holderView", newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
        /// getter 方法
        get {
            
            let obj = (objc_getAssociatedObject(self, "holderView") as? FrankPlaceHolderView)
            
            if obj != nil {
                
                return obj
            }
            
            return FrankPlaceHolderView()
        }
    }
    
    var tableViewSepStyle:UITableViewCellSeparatorStyle {
        
        set {
            objc_setAssociatedObject(self, "tableViewSepStyle", tableViewSepStyle, .OBJC_ASSOCIATION_ASSIGN)
        }
        get {
            return (objc_getAssociatedObject(self, "tableViewSepStyle") as? UITableViewCellSeparatorStyle)!
        }
    }
    
    
    
    /// 添加占位视图
    ///
    /// - Parameters:
    ///   - position:  重载按钮位置
    ///   - showImage: 展示占位图片
    ///   - showDescribe: 展示占位提示文字
    ///   - btnTitle: 重载按钮提示文字
    ///   - btnClickBlock: 重载按钮点击之后回调
    func showPlaceHolderViewWithReloadButtonPosition(position:ReloadButtonPosition? = .ReloadButtonPosition_None,
                                                     showImage:UIImage? = UIImage.init(named: "FrankPlaceHolder.bundle/暂无数据.png"),
                                                     showDescribe:NSString? = "暂无数据",
                                                     btnTitle:NSString? = "重新加载",
                                                     btnClickBlock:(()->())? = nil) {
        
        if self.holderView != nil {
            
            if self is UIScrollView {
            
                (self as! UIScrollView).isScrollEnabled = false
                
                if self is UITableView {
                    
                    self.tableViewSepStyle = (self as! UITableView).separatorStyle
                    (self as! UITableView).separatorStyle = .none
                }
            }
            
            let holderView = FrankPlaceHolderView.init(frame: CGRect(x: 0, y: 0, width: self.frame.width, height: self.frame.height))
            holderView.backgroundColor = UIColor.white
            
            /// KVC 设置属性
            holderView.setValue(showImage, forKey: "showImage")
            holderView.setValue(showDescribe, forKey: "showDescribe")
            holderView.setValue(btnTitle, forKey: "showReloadBtnTitle")
            
            holderView.reloadButtonClickBlock = btnClickBlock
            holderView.btnPosition = position!
            
            self.addSubview(holderView)
            self.bringSubview(toFront: holderView)
            self.holderView = holderView
            
        }
        
    }
    
    /// 隐藏占位视图
    func hiddenPlaceHolderView() {
        
        if self.holderView != nil {
            
            if self is UIScrollView {
                
                (self as! UIScrollView).isScrollEnabled = true
                
                if self is UITableView {
                    
                    (self as! UITableView).separatorStyle = self.tableViewSepStyle
                }
            }
            
            for chilren in self.subviews {
                
                if chilren is FrankPlaceHolderView {
                    
                    chilren.removeFromSuperview()
                }
            }
            self.holderView = nil
        }
    }
}

class FrankPlaceHolderView: UIView {
    
    ///  按钮展示位置
    var btnPosition:ReloadButtonPosition = UIView.ReloadButtonPosition(rawValue: 0)!
    
    /// 展示图片
    private var imgView : UIImageView!
    /// 重载按钮
    private var reloadBtn : UIButton!
    /// 描述label
    private var desLabel : UILabel!
    
    /// 展示的展位图片
     var showImage:UIImage!
    /// 展示的提示文字
     var showDescribe:NSString!
    /// 展示的按钮提示文字
     var showReloadBtnTitle:NSString!
    
    /// 重载按钮点击之后的回调闭包
    var reloadButtonClickBlock : (()->())?
    
    /// KVC 监控一些不存在的键值
    override func setValue(_ value: Any?, forUndefinedKey key: String) {
        
        print("\n--- key = %@ \n--- value = %@",key,value ?? "???")
        
    }
    override func layoutSubviews() {
        super.layoutSubviews();
        
        self.setupViews()
    }
    
    func setupViews() {
        
        let height:CGFloat = self.bounds.height
        let width:CGFloat = self.bounds.width
        var imgWidth:CGFloat = width/2
        
        if width >= height {
            
            imgWidth = imgWidth*height*2/(width*3)
        }
        let imgHeight:CGFloat = self.showImage.size.height*imgWidth/self.showImage.size.width;
        
        let imgView = UIImageView(image: self.showImage);
        imgView.bounds = CGRect(x: 0, y: 0, width: imgWidth, height: imgHeight);
        imgView.center = CGPoint(x: self.center.x, y: self.center.y-imgView.bounds.height/2)
        self.imgView = imgView
        
        let font:CGFloat = 15.0 * (self.bounds.width/UIScreen.main.bounds.width)
        let r:CGRect = self.showDescribe.boundingRect(with:CGSize(width: self.bounds.width-30, height: 35), options: .usesLineFragmentOrigin, attributes: [NSFontAttributeName:UIFont.systemFont(ofSize: font)], context: nil)
        
        let desLabel = UILabel.init()
        desLabel.bounds = CGRect(x: 0, y: 0, width: self.bounds.width-30, height: r.size.height)
        desLabel.center = CGPoint(x: self.center.x, y: imgView.frame.maxY + desLabel.bounds.height + 10)
        desLabel.numberOfLines = 2
        desLabel.textColor = UIColor.init(white: 0.5, alpha: 1.0)
        desLabel.font = UIFont.systemFont(ofSize: font)
        desLabel.text = self.showDescribe! as String
        desLabel.textAlignment = .center
        self.desLabel = desLabel
        
        let showBtn = UIButton.init(type: .custom)
        showBtn.bounds = CGRect(x: 0, y: 0, width: self.bounds.width-60, height: 30)
        showBtn.setTitle(self.showReloadBtnTitle! as String, for: .normal)
        showBtn.backgroundColor = UIColor.init(red: 49/255.0, green: 194/255.0, blue: 124/255.0, alpha: 1.0)
        showBtn.setTitleColor(UIColor.white, for: .normal)
        showBtn.titleLabel?.font = UIFont.systemFont(ofSize: font)
        
        switch self.btnPosition {
        case .ReloadButtonPosition_ImgTop:
            showBtn.center = CGPoint(x: self.center.x, y: imgView.frame.origin.y - showBtn.bounds.height - 10)
            
        case .ReloadButtonPosition_ImgButtom:
            showBtn.center = CGPoint(x: self.center.x, y: desLabel.frame.maxY + desLabel.bounds.height + 10)
        
        case .ReloadButtonPosition_ViewBottom:
            showBtn.center = CGPoint(x: self.center.x, y: self.bounds.height - showBtn.bounds.height - 10)
        
        default: break
            
        }
        
        showBtn.addTarget(self, action:#selector(reloadBtnClickMethod), for: .touchUpInside)
        self.reloadBtn = showBtn
        
        self.addSubview(self.imgView)
        self.addSubview(self.desLabel)
        
        if self.btnPosition != .ReloadButtonPosition_None {
            
            showBtn.layer.cornerRadius = 8.0
            showBtn.layer.masksToBounds = true
            showBtn.layer.borderWidth = 0
            showBtn.layer.borderColor = UIColor.white.cgColor
            
            self.addSubview(self.reloadBtn)
        }
        
    }
    
    func reloadBtnClickMethod() {
        
        self.reloadButtonClickBlock?()
    }
}

